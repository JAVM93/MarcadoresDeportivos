import React from 'react';

import ReactDom from 'react-dom/client'
import './css/bootstrap.min.css'
import {BrowserRouter as Router, Switch,Route, Routes} from 'react-router-dom';
import {Mensaje, Registrados} from './Mensaje'
import Header, {Menu} from './elements/Header';
import {Tablero} from './dashboard/Tablero'
import {Equipo} from './Equipo'
import { ListaEventos } from './events/ListaEventos';
import {Login} from './users/Login'

const root = ReactDom.createRoot(document.getElementById('root'))
root.render(
    <> 
    
        <Router>
        <Menu/>
        <div className="row my-2">
            <div className="container">
                <div className="row align-center">
                    <div className='col m-5'>
                    
                        <Routes>
                            <Route path='/' exact element={<ListaEventos />}/>
                            {/* <ListaEventos/> */}
                            {/* <Route path='/tablero' exact component={Tablero}/> */}
                            {/* <Tablero/> */}
                            <Route path='/login' exact element={<Login />}/>
                            {/* <Login/> */}
                            </Routes>
                            
                    </div>
                    
                    
                </div>
                
            </div>
        </div>
        </Router>
        
    </>
)