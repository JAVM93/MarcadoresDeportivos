import {Evento} from './Evento' 
export function ListaEventos(){
    return <div className="col-6 offset-2">
    <Evento/>
    </div>
}