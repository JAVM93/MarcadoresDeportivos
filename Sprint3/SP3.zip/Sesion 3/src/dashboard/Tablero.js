export function Tablero(){
    return <div className="row">
        <div className="col-3">
            <h5>Menu</h5>
        </div>
        <div className="col-9">
            Opciones
        </div>

    </div>
}