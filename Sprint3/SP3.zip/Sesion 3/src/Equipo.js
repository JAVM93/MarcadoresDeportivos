export function Equipo(props){
    const etiqueta = { display: "block",
    border: "1px solid salmon",
    height: "340px",
    padding: "10px",
    width: "150px" } 
    const dato = {  }
    return <>
    <div style={etiqueta}>
        <ul>

        </ul>
        <li>nombre : <p style={ {color: "red"}} >{ props.nombre }</p></li>
        <li>partidos jugados: { props.jugados }</li>
        promedio : { props.promedio }
        ultimo partido : { props.ultimo }
        record : gan { props.record[0] } / perd { props.record[1] }
        juega internacional: { props.internacional ? "Si" : "No" }
        ubicado en : ({ props.ubicado.pais } / { props.ubicado.ciudad }  )
    </div>
        
    </>
}